#NodeTask Steps

## Steps to be followed

# Frontend

* npm install
* npm start

# Backend

* npm install
* node app.js
* Server url: http://localhost:3001

# Apis -

 * GET 
 * /getEnvironment/:process
 * Example http://localhost:3001/getEnvironment/P1
 
 
 * GET 
 * /setEnvironment/:process/:key/:value
 * Example http://localhost:3001/setEnvironment/P1/testkey/testvalue

